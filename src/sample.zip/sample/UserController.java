
package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class UserController {

    @FXML
    private TableView<Pies> table2;

    @FXML
    private TableColumn< Pies,Integer> IdView;

    @FXML
    private TableColumn<Pies,String> NameView;

    @FXML
    private TableColumn<Pies,Double > PriceView;

    @FXML
    private TableColumn<Pies,Integer> AmountView;

    @FXML
    private Button ButtonAdd;

    @FXML
    private TextField amountfield;

    @FXML
    private Label AmountSignUp;

    @FXML
    private Button ButtonDelete;

    @FXML
    private Button ButtonSend;

    @FXML
    private Label ExitSignUp;


}
