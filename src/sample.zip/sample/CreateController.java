package sample;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

    public class CreateController {
        @FXML
        private TextField signUpButtonLogin;

        @FXML
        private Button AuthoButton;

        @FXML
        private TextField signUpButtonName;

        @FXML
        private TextField signUpButtonSurname;

        @FXML
        private TextField signUpButtonPassword;

        @FXML
        private TextField signUpButtonID;

    }
