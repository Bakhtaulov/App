package sample;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class AdminkaController {

    @FXML
    private Label AddSignUp;

    @FXML
    private TextField NameFieldUp;

    @FXML
    private TextField PriceFieldUp;

    @FXML
    private TextField DiscountFieldUp;

    @FXML
    private Button ButtonAdd;

    @FXML
    private Button DeleteButton;

    @FXML
    private Label ExitButton;

    @FXML
    private TableView<Pies> table;

    @FXML
    private TableColumn<Pies,Integer> IdsignUp;

    @FXML
    private TableColumn<Pies,String> NameSignUp;

    @FXML
    private TableColumn<Pies,Double> PriceSignUp;

    @FXML
    private TableColumn<Pies,Integer> DiscountSignUp;




}

